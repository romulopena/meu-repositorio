//((mostrar e movimentar cabeça vaca))

let xCabecaVaca = 50;
let yCabecaVaca = 370;
let bateu = false;
let pontuacao = 0;

function aparecerCabecaVaca(){
  image(cabecaDeVaca, xCabecaVaca, yCabecaVaca, 20,25)
}
function movimentoCabecaVaca(){
  //yCabecaVaca = yCabeca + 3;  ((descer vaca))
  if (keyIsDown(DOWN_ARROW)){
    if (podeSeMover()){
          yCabecaVaca += 3;
  }
  }   
  //yCabecaVaca = yCabeca - 3;  ((subir vaca))
  if (keyIsDown(UP_ARROW)){
          yCabecaVaca -= 3;
    
  }
}

function verificaBateu(){
  //collideRectCircle(x1, y1, width1, height1, cx, cy, diameter)
  for (i = 0; i < imagemDosCarros.length; i = i + 1){
    bateu = collideRectCircle(xCarros[i], yCarros[i],larguraCarros, alturaCarros,xCabecaVaca,yCabecaVaca,15);
  
  if (bateu){
    voltarComeco();
    somDaBatida.play();
    if (pontosMaiorQueZero()){
    pontuacao -= 1;
    }
   }
  }
}
function voltarComeco(){
  yCabecaVaca = 370;

}

function mostraPontos(){
  fill(75,0,130);
  textSize(30);
  text(pontuacao, width / 5, 28 );
}

function marcaPontos(){
  if (yCabecaVaca < 15){
    somDosPontos.play();
    pontuacao +=1;
    voltarComeco();
  }
}
function pontosMaiorQueZero(){
  return pontuacao > 0;
}

function podeSeMover(){
  return yCabecaVaca < 370;
}