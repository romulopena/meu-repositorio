//(((mostrar e movimentar o carro)))
//carros [carro1,carro2,carro3];
let xCarros = [550,550,550,550,550,550];
let yCarros = [45,100,155,205,260,315];
let velocidadeCarros = [3.5,2.9,2.65,3.1,2.5,4.0];
let larguraCarros = 50;
let alturaCarros = 30;


function aparecerCarro(){
  //laço de repetição com variável nova "i" para substituir nos valores da lista de carros
  for (i = 0; i < imagemDosCarros.length; i = i + 1){
  image(imagemDosCarros[i], xCarros[i],yCarros[i],larguraCarros,alturaCarros);
  }
}
function movimentoDoCarro() {
  for (i = 0; i < imagemDosCarros.length; i = i + 1){
  //xCarro = xCarro - 6;   (((carro desliza)))
  xCarros[i] -= velocidadeCarros[i];
  }
} 
function voltarParaInicioPista(){
  for (i = 0; i < imagemDosCarros.length; i = i + 1){
    if (carroPassouTodaTela(xCarros)){
      xCarros[i]= 550;
   }
 }
}
 


function carroPassouTodaTela(xCarros){
   return xCarros[i] < -60;
    
}