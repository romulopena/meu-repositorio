//imagens e cenario do jogo e sons do jogo
let imagemDaEstrada; 
let imagemDoCarro1;
let atorCabecaDeVaca;
let somDaTrilha;
let somDosPontos;
let somDaBatida;

//pré-carregando a imagem 
function preload(){
  //variaveis recebendo carregamento de imagem
  imagemDaEstrada = loadImage("imagens/estrada.png");
  imagemDoCarro1 = loadImage("imagens/carro-1.png");
  imagemDoCarro2 = loadImage("imagens/carro-2.png");
  imagemDoCarro3 = loadImage("imagens/carro-3.png");
  cabecaDeVaca = loadImage("imagens/ator-1.png");
  //criando lista de todos os carros
  imagemDosCarros = [imagemDoCarro1,imagemDoCarro2 ,imagemDoCarro3,imagemDoCarro1,imagemDoCarro2 ,imagemDoCarro3];
  
  somDaTrilha = loadSound("sons/trilha.mp3");
  somDosPontos = loadSound("sons/pontos.wav");
  somDaBatida = loadSound("sons/colidiu.mp3");
  
}